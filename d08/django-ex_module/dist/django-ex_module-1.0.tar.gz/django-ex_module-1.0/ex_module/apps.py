from django.apps import AppConfig


class ExConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ex_module'
